{{/*
Copyright IBM, Inc. All Rights Reserved.
SPDX-License-Identifier: APACHE-2.0
*/}}

{{/* vim: set filetype=mustache: */}}

{{- define "clusterId" -}}
{{ default .Values.clusterId .Values.global.clusterId }}
{{- end -}}

{{/*
Return the proper FinOps Agent&trade; Core image name
*/}}
{{- define "finops-agent.image" -}}
{{ include "common.images.image" (dict "imageRoot" .Values.image "global" .Values.global) }}
{{- end -}}

{{/*
Return the proper Docker Image Registry Secret Names
*/}}
{{- define "finops-agent.imagePullSecrets" -}}
{{ include "common.images.pullSecrets" (dict "images" (list .Values.image ) "global" .Values.global) }}
{{- end -}}

{{/*
Create the name of the ServiceAccount to use
*/}}
{{- define "finops-agent.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "common.names.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Return if the finops agent should create
*/}}
{{- define "finops-agent.exportBucket.secret.create" -}}
{{- if and (not (empty .Values.exportBucket.secret.existingSecret)) .Values.exportBucket.secret.config }}
{{ fail "Cannot set both exportBucket.secret.existingSecret and exportBucket.secret.config" }}
{{- end }}
{{- if .Values.exportBucket.secret.config }}
true
{{- else }}
false
{{- end }}
{{- end }}

{{/*
define the name of the export secret bucket
*/}}
{{- define "finops-agent.exportBucket.secretName" }}
{{- if (.Values.global.exportBucket).existingSecret }}
.Values.exportBucket.existingSecret
{{- else }}
{{ .Release.Name }}-export-bucket-config
{{- end }}
{{- end }}

{{- define "finops-agent.exportBucket.fileName" }}
{{ default "storage-config.yaml" (.Values.global.exportBucket).fileName }}
{{- end }}

{{/*
define the name of the cloudability secret
*/}}
{{- define "cloudability.secret.name" }}
{{- if .Values.agent.cloudability.secret.create }}
{{ .Release.Name }}-cloudability-secrets
{{- else }}
{{.Values.agent.cloudability.secret.existingSecret}}
{{- end }}
{{- end }}